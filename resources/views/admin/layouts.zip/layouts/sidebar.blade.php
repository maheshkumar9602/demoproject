<style>
    .app-sidebar:before {
    content: '';
    position: absolute;
    width: 100%;
    height: 50px;
    display: block;
}
</style>

<aside class="app-sidebar">
    <div class="side-header">
        
        <a aria-label="Hide Sidebar" class="app-sidebar__toggle ml-auto" data-toggle="sidebar" href="#"></a><!-- sidebar-toggle-->
    </div>
    <div class="app-sidebar__user">
        <div class="dropdown user-pro-body text-center">
            <div class="user-pic">
                <img src="{{ asset('/uploads/profile/default.png')}}" alt="user-img" class="avatar-xl rounded-circle">
            </div>
            <div class="user-info">
                <h6 class=" mb-0 text-dark">{{Auth::guard('admin')->user()->name }}</h6>
                <span class="text-muted app-sidebar__user-name text-sm"></span>
            </div>
        </div>
    </div>
    <div class="sidebar-navs">
        <ul class="nav  nav-pills-circle">
          
            <li class="nav-item" data-toggle="tooltip" data-placement="top" title="Home">
                <a class="nav-link text-center m-2" href="{{ route('admin.dashboard') }}">
                    <i class="fe fe-home"></i>
                </a>
            </li>
            
            <li class="nav-item" data-toggle="tooltip" data-placement="top" title="Logout">
                <a class="nav-link text-center m-2" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <i class="fe fe-power"></i>
                </a>
                <form id="logout-form" action="{{ route('admin.logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
            </li>
        </ul>
    </div>
    <ul class="side-menu">
        <li>
            <a class="side-menu__item" href="{{ route('admin.dashboard') }}"><i class="side-menu__icon ti-home"></i><span class="side-menu__label">Dashboard</span></a>
        </li>

   
	   <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fa fa-picture-o"></i><span class="side-menu__label">Blog</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.blog-list') }}" class="slide-item">Blogs List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.blog-create') }}" class="slide-item">Create Blog<a>
                </li>
            
            </ul>
        </li>
         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">Category</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.category-list') }}" class="slide-item">Category List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.category-create') }}" class="slide-item">Create Category<a>
                </li>
            
            </ul>
        </li>

         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">Subcategory</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.subcategory-list') }}" class="slide-item">Subcategory List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.subcategory-create') }}" class="slide-item">Create Subcategory<a>
                </li>
            
            </ul>
        </li>

         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">PageCategory</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.pagecategory-list') }}" class="slide-item">PageCategory List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.pagecategory-create') }}" class="slide-item">Create PageCategory<a>
                </li>
            
            </ul>
        </li>

         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">Pages</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.pages-list') }}" class="slide-item">Pages List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.pages-create') }}" class="slide-item">Create Pages<a>
                </li>
            
            </ul>
        </li>

         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">Brand</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.brand-list') }}" class="slide-item">Brand List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.brand-create') }}" class="slide-item">Create Brand<a>
                </li>
            
            </ul>
        </li>

         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">SliderCategory</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.slidercategory-list') }}" class="slide-item">SliderCategory List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.slidercategory-create') }}" class="slide-item">Create SliderCategory<a>
                </li>
            
            </ul>
        </li>

        <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">Slider</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.slider-list') }}" class="slide-item">Slider List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.slider-create') }}" class="slide-item">Create Slider<a>
                </li>
            
            </ul>
        </li>


        <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">Products</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.products-list') }}" class="slide-item">Products List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.products-create') }}" class="slide-item">Create Products<a>
                </li>
            
            </ul>
        </li>
	
         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">Country</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.country-list') }}" class="slide-item">Country List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.country-create') }}" class="slide-item">Create Country<a>
                </li>
            
            </ul>
        </li>

         <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon ti-user"></i><span class="side-menu__label">State</span> <i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
        
                <li>
                    <a href="{{ route('admin.state-list') }}" class="slide-item">State List<a>
                </li>
            
        
                <li>
                    <a href="{{ route('admin.state-create') }}" class="slide-item">Create State<a>
                </li>
            
            </ul>
        </li>
    
    </ul>



</aside>

